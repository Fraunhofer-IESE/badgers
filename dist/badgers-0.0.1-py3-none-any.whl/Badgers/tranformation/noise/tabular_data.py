import abc

from numpy.random import default_rng
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_array


class NoiseTransformer(TransformerMixin, BaseEstimator):
    def __init__(self, random_generator=default_rng(seed=0)):
        """

        Parameters
        ----------
        random_generator : numpy.random.Generator, defaut default_rng(seed=0)
            A random generator
        """
        self.random_state = random_generator

    @abc.abstractmethod
    def transform(self, X):
        pass


class GaussianNoiseTransformer(NoiseTransformer):
    def __init__(self, random_generator=default_rng(seed=0), signal_to_noise_ratio: float = 0.1):
        """

        Parameters
        ----------
        random_generator : numpy.random.Generator, default default_rng(seed=0)
            A random generator
        """
        super().__init__(random_generator=random_generator)
        self.signal_to_noise_ratio = signal_to_noise_ratio

    def transform(self, X):
        X = check_array(X, accept_sparse=False)
        #
        scaler = StandardScaler()
        # fit, transform
        scaler.fit(X)
        Xt = scaler.transform(X)
        # add noise
        Xt = Xt + self.random_state.normal(loc=0, scale=self.signal_to_noise_ratio, size=Xt.shape)
        # inverse pca
        return scaler.inverse_transform(Xt)
