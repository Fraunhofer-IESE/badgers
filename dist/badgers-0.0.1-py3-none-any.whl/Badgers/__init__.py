"""Top-level package for Badgers."""

__author__ = """Julien Siebert"""
__email__ = 'julien.siebert@iese.fraunhofer.de'
__version__ = '0.0.1'
