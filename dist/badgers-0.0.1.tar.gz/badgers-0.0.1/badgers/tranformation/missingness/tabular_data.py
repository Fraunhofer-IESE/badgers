import numpy as np
import numpy.random
import pandas as pd
from numpy.random import default_rng
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.utils.validation import check_array


def normalize_proba(p):
    """
    Make sure the probability array respects the following constraints:
     - the sum of each column must be equal to 1 (or very close to 1)
    Parameters
    ----------
    p

    Returns
    -------

    """
    # make the sum of each column = 1
    sum = p.sum(axis=0)
    # assure that no division by 0
    sum[sum == 0] = 1
    # normalize
    p = p / sum
    return p


class MissingValueTransformer(TransformerMixin, BaseEstimator):
    def __init__(self, percentage_missing: int = 10, random_generator: numpy.random.Generator = default_rng(seed=0),
                 missingness_proba_func=None):

        """ Base class for missing values transformer

        Parameters
        ----------
        percentage_missing : int, default 10
            The percentage of missing values (int value between 0 and 100 included)
        random_generator : numpy.random.Generator, defaut default_rng(seed=0)
            A random generator
        missingness_proba_func : func, default None
            A function computing the probability of missingness for the data to be transformed.
            This function should take X ({array-like}, shape (n_samples, n_features)) as input
            and outputs an array p ({array-like}, shape (n_samples, n_features))
            containing the missingness probabilities
        """
        assert 0 <= percentage_missing <= 100
        self.percentage_missing = percentage_missing
        self.random_generator = random_generator
        self.missingness_proba_func = missingness_proba_func
        self.missing_indices = []

    def transform(self, X):
        """ Randomly (uniformely) replace values with np.nan
        Parameters
        ----------
        X : {array-like, sparse-matrix}, shape (n_samples, n_features)
            The input samples.
        Returns
        -------
        X_transformed : array, shape (n_samples, n_features)
            The array containing missing values.
        """
        X = check_array(X, accept_sparse=False)

        # compute number of missing values per column
        nb_missing = int(X.shape[0] * self.percentage_missing / 100)

        # compute missingness probability
        p = self.missingness_proba_func(X)
        # sanity check, p must have the same shape as X
        if p.shape != X.shape:
            error_text = f"The function computing the missingness probability (missingness_proba_func) " \
                         f"should return an array p of the same shape as X\n" \
                         f"X has shape {X.shape} and p has shape {p.shape} which are different."
            raise ValueError(error_text)
        # generate missing values
        for col in range(X.shape[1]):
            rows = self.random_generator.choice(X.shape[0], size=nb_missing, replace=False, p=p[:, col])
            X[rows, col] = np.nan
            self.missing_indices += [(row, col) for row in rows]

        return X


class MissingCompletelyAtRandom(MissingValueTransformer):

    def __init__(self, percentage_missing: int = 10, random_generator=default_rng(seed=0)):
        """ A transformer that removes values completely at random (MCAR [1]) (uniform distribution over all data).

        See also [1] https://stefvanbuuren.name/fimd/sec-MCAR.html

        Parameters
        ----------
        percentage_missing : int, default 10
            The percentage of missing values (int value between 0 and 100 included)
        random_generator : numpy.random.Generator, defaut default_rng(seed=0)
            A random generator
        """
        super().__init__(percentage_missing=percentage_missing, random_generator=random_generator,
                         missingness_proba_func=None)

    def transform(self, X):
        X = check_array(X, accept_sparse=False)

        # compute number of missing values per column
        nb_missing = int(X.shape[0] * self.percentage_missing / 100)

        # generate missing values
        for col in range(X.shape[1]):
            rows = self.random_generator.choice(X.shape[0], size=nb_missing, replace=False, p=None)
            X[rows, col] = np.nan
            self.missing_indices += [(row, col) for row in rows]

        return X


class DummyMissingAtRandom(MissingValueTransformer):

    def __init__(self, percentage_missing: int = 10, random_generator=default_rng(seed=0)):
        """

        Parameters
        ----------
        percentage_missing : int, default 10
            The percentage of missing values (int value between 0 and 100 included)
        random_generator : numpy.random.Generator, defaut default_rng(seed=0)
            A random generator
        """

        def missingness_probability(X):
            if isinstance(X, pd.DataFrame):
                X = X.to_numpy()
            # initialize probability with zeros
            p = np.zeros_like(X)
            # normalize values between 0 and 1
            X_norm = (X.max(axis=0) - X) / (X.max(axis=0) - X.min(axis=0))
            # make columns i depends on all the other
            if X.shape[1] > 1:
                for i in range(X.shape[1]):
                    p[:, i] = np.delete(X_norm, i, axis=1).sum(axis=1)
            else:
                p = X_norm
            p = normalize_proba(p)
            return p

        super().__init__(percentage_missing=percentage_missing, random_generator=random_generator,
                         missingness_proba_func=missingness_probability)


class DummyMissingNotAtRandom(MissingValueTransformer):

    def __init__(self, percentage_missing: int = 10, random_generator=default_rng(seed=0)):
        """

        Parameters
        ----------
        percentage_missing : int, default 10
            The percentage of missing values (int value between 0 and 100 included)
        random_generator : numpy.random.Generator, defaut default_rng(seed=0)
            A random generator
        """

        def missingness_probability(X):
            if isinstance(X, pd.DataFrame):
                X = X.to_numpy()
            # normalize values between 0 and 1
            p = (X.max(axis=0) - X) / (X.max(axis=0) - X.min(axis=0))
            # make the sum of each column = 1
            p = normalize_proba(p)
            return p

        super().__init__(percentage_missing=percentage_missing, random_generator=random_generator,
                         missingness_proba_func=missingness_probability)
