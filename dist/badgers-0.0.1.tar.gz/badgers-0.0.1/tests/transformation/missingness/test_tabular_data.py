import unittest
from unittest import TestCase

import numpy as np
import pandas as pd
from numpy.random import default_rng

from old_badgers.tranformation.missingness.tabular_data import MissingCompletelyAtRandom, MissingValueTransformer, \
    DummyMissingAtRandom, DummyMissingNotAtRandom, normalize_proba


class TestUtils(TestCase):

    def setUp(self) -> None:
        self.rng = default_rng(0)

    def test_normalize_proba(self):
        p = self.rng.uniform(0, 1, size=(3, 5))
        p = normalize_proba(p)
        self.assertEqual(p.shape, (3, 5))
        for s in p.sum(axis=0).tolist():
            self.assertAlmostEqual(s, 1.0)


class TestDummyMissingAtRandom(unittest.TestCase):
    def setUp(self) -> None:
        self.rng = default_rng(0)
        self.missing_transformer = DummyMissingAtRandom(percentage_missing=10, random_generator=default_rng(seed=0))

    def test_missingness_probability_function_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        self.assertEqual(p.sum(), 1.0)

    def test_missingness_probability_function_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        for s in p.sum(axis=0).tolist():
            self.assertAlmostEqual(s, 1.0)

    def test_missingness_probability_function_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        self.assertEqual(p.sum(), 1.0)

    def test_missingness_probability_function_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        for s in p.sum(axis=0).tolist():
            self.assertAlmostEqual(s, 1.0)

    def test_transform_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)

    def test_transform_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)


class TestDummyMissingNotAtRandom(unittest.TestCase):
    def setUp(self) -> None:
        self.rng = default_rng(0)
        self.missing_transformer = DummyMissingNotAtRandom(percentage_missing=10, random_generator=default_rng(seed=0))

    def test_missingness_probability_function_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        self.assertEqual(p.sum(), 1.0)

    def test_missingness_probability_function_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        for s in p.sum(axis=0).tolist():
            self.assertAlmostEqual(s, 1.0)

    def test_missingness_probability_function_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        self.assertEqual(p.sum(), 1.0)

    def test_missingness_probability_function_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        p = self.missing_transformer.missingness_proba_func(X)
        self.assertEqual(X.shape, p.shape)
        for s in p.sum(axis=0).tolist():
            self.assertAlmostEqual(s, 1.0)

    def test_transform_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)

    def test_transform_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)


class TestMissingCompletelyAtRandom(unittest.TestCase):
    def setUp(self) -> None:
        self.rng = default_rng(0)
        self.missing_transformer = MissingCompletelyAtRandom(percentage_missing=10,
                                                             random_generator=default_rng(seed=0))

    def test_transform_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)

    def test_transform_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)


class TestMissingValueTransformer(unittest.TestCase):
    def setUp(self) -> None:
        self.rng = default_rng(0)

        def missingness_probability(X):
            # normalize values between 0 and 1
            X_norm = (X.max(axis=0) - X) / (X.max(axis=0) - X.min(axis=0))
            # make the sum of each column = 1
            p = X_norm / X_norm.sum(axis=0)
            return p

        self.missing_transformer = MissingValueTransformer(percentage_missing=10, random_generator=default_rng(seed=0),
                                                           missingness_proba_func=missingness_probability)

    def test_transform_numpy_1D_array(self):
        X = self.rng.normal(size=(10)).reshape(-1, 1)
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_numpy_2D_array(self):
        X = self.rng.normal(size=(100, 10))
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)

    def test_transform_pandas_1D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(10)).reshape(-1, 1),
            columns=['col']
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 1)

    def test_transform_pandas_2D_array(self):
        X = pd.DataFrame(
            data=self.rng.normal(size=(100, 10)),
            columns=[f'col{i}' for i in range(10)]
        )
        X_transformed = self.missing_transformer.transform(X)
        # assert arrays have same shape
        self.assertEqual(X.shape, X_transformed.shape)
        # assert number of nans
        self.assertEqual(np.isnan(X_transformed).sum(), 100)


if __name__ == '__main__':
    unittest.main()
